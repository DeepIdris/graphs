package lab2;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class InsuranceBVATest {
	private static Object[][] testData = new Object[][] {
		//  testid,   age,	gender,	married, expected output
		{ "T1.1",     16,	'M', 	false,	2000 },
		{ "T1.2",     24,	'M', 	false,	2000 },
		{ "T1.3",     25,   'F',	false,	300 },
		{ "T1.4",     45,   'M',	false,	400 },
		{ "T1.5",     44,   'M',	false,	500 },
		{ "T1.6",     65,   'M',	true,	200 },
		{ "T1.7",     Integer.MIN_VALUE,   	'M',	true,	0 },
		{ "T1.8",     15,   	'M',	true,	0 },
		{ "T1.9",     66,  'F',	false,	0 },
		{ "T1.10",     Integer.MAX_VALUE,  'F',	false,	0 },
		{ "T1.11",     20,   'O',	false,	0 },
	};

	@DataProvider(name="insuranceTest")
	public Object[][] getTestData() {
		return testData;
	}

	@Test(dataProvider="insuranceTest")
	public void test_giveDiscount( String id, int age, char gender, boolean married, int expected) {
		assertEquals( Insurance.premium(age, gender, married), expected );
	}

}
